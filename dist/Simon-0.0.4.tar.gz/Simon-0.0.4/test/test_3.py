def test_function_creates_matrix():
    matrix = 'ATCG'
    assert len(matrix) == 4
